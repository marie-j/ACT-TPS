package pizza;

public class Case {

		public int x;
		public int y;
		
		public Case(int x, int y) {
			this.x = x;
			this.y = y;
		}
}
