package pizza;

import java.util.List;

public class Part {

	protected List<Case> cases;
	
	public Part(List<Case> cases) {
		this.cases = cases;
	}
}
