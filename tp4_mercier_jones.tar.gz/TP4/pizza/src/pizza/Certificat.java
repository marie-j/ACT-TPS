package pizza;

public interface Certificat {
	  
	 public boolean estCorrect();

	 public void suivant();

	 public boolean estDernier();
	 
	 public void alea();
	 
	 public void affiche();
	
}
