package binpack;

public abstract class PblDec{

public PblDec(){};

abstract public boolean aUneSolution();
}
